# -*- coding: utf-8 -*-

{
    'name': 'Mobile Shop',
    'version': '1.0',
    'category': 'Services',
    'summary': 'Manage mobile services and repairs',
    'author': 'Your Name',
    'images': ['static/description/icon.png'],
    'depends': ['base','product','sale','mail'],
    'license': 'LGPL-3',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/mobile_shop_views.xml',
        'views/reject_reason_wizard.xml',
        'data/data_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}



