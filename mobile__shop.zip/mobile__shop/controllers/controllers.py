# -*- coding: utf-8 -*-
# from odoo import http


# class MobileShop(http.Controller):
#     @http.route('/mobile__shop/mobile__shop', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/mobile__shop/mobile__shop/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('mobile__shop.listing', {
#             'root': '/mobile__shop/mobile__shop',
#             'objects': http.request.env['mobile__shop.mobile__shop'].search([]),
#         })

#     @http.route('/mobile__shop/mobile__shop/objects/<model("mobile__shop.mobile__shop"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('mobile__shop.object', {
#             'object': obj
#         })
