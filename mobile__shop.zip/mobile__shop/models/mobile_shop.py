from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import date
from odoo.exceptions import ValidationError


class BrandName(models.Model):
    _name = 'brand.name'
    _description = 'Mobile Brand Name'


    name = fields.Char(string='Brand Name', required=True, tracking=True)


    @api.constrains('name')
    def _check_unique_name(self):
        for record in self:
            duplicate = self.search([('name', '=', record.name)], limit=1)
            if duplicate and duplicate.id != record.id:
                raise ValidationError(_("Name %s Already Exists") % record.name)


class DamagedSparePart(models.Model):
    _name = 'damaged.spare.part'
    _inherit=['mail.thread']
    _description = 'Damaged Spare Part'

    name = fields.Char(string='Spare Part Name', required=True, tracking=True)


class MobileShop(models.Model):
    _name = 'mobile.shop'
    _description = 'Mobile Shop'
    _inherit = ['mail.thread']


    sequence_id = fields.Char(
        string="Order Reference",
        required=True, copy=False, readonly=True,
        index=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: _('New')
    )

    empty_id=fields.Char(
        string="Order Reference",
        required=True, copy=False, readonly=True,
        index=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: _('New')
    )

    customer_name = fields.Many2one('res.partner', string='Customer Name', required=True,tracking=True)
    phone = fields.Char(related='customer_name.phone', string='Customer Phone', required=True,tracking=True)
    mobile_os_type = fields.Selection([
        ('android', 'Android'),
        ('basic', 'Basic'),
        ('ios', 'iOS'),
    ], string='Mobile OS Type', required=True, tracking=True)


    mobile_company_id = fields.Many2one('brand.name', string='Mobile Company')

    user_name = fields.Char(string='User Name', default=lambda self: self.env.user.name, readonly=True)
    company_name = fields.Char(string='Company Name', default=lambda self: self.env.company.name, readonly=True)

    complaint_description = fields.Text(string='Mobile Complaint Description')
    service_line_ids = fields.One2many('mobile.shop.service.line', 'mobile_shop_id', string='Mobile Service Line')
    total = fields.Float(string='Total', compute='_compute_total', store=True)

    damaged_spare_parts_ids = fields.Many2many('damaged.spare.part', string='Damaged Spare Parts')

    state = fields.Selection([
        ('draft', 'Draft'),
        ('waiting_for_approval', 'Waiting for Approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('cancel', 'Cancel'),
    ], string='State', tracking=True, default='draft')

    reject_reason = fields.Text(string='Rejection Reason')

    company_id = fields.Many2one(
        'res.company', string='Company',
        default=lambda self: self.env.company, required=True
    )

    user_id = fields.Many2one(
        'res.users', string='User',
        default=lambda self: self.env.user, required=True
    )

    @api.depends('service_line_ids.subtotal')
    def _compute_total(self):
        print("Compute with depends")
        for record in self:
            record.total = sum(line.subtotal for line in record.service_line_ids) 

    @api.model
    def create(self, vals):
        if vals.get('sequence_id', _('New')) == _('New'):
            vals['sequence_id'] = self.env['ir.sequence'].next_by_code('mobile.shop.sequence') or _('New')
        return super(MobileShop, self).create(vals)

    def action_send_for_approval(self):
        for record in self:
            if record.state == 'draft':
                if record.sequence_id == _('New'):  # Generate only if it hasn't been set
                    record.sequence_id = self.env['ir.sequence'].next_by_code('mobile.shop.sequence') or _('New')
            record.state = 'waiting_for_approval'


    @api.model
    def create(self, vals):
        if vals.get('empty_id', _('New')) == _('New'):
            vals['empty_id'] = self.env['ir.sequence'].next_by_code('mobile.shop.empty') or _('New')
        return super(MobileShop, self).create(vals)

    def action_send_for_approval(self):
        for record in self:
            if record.state == 'draft':
                if record.empty_id == _('New'):  # Generate only if it hasn't been set
                    record.empty_id = self.env['ir.sequence'].next_by_code('mobile.shop.empty') or _('New')
            record.state = 'waiting_for_approval'


    def action_approve(self):
        if not self.env.user.has_group('mobile__shop.group_sales_manager'):
            raise UserError("Only Sales Managers can approve this form.")
        self.state = 'approved'

    def action_reject(self):
        if not self.env.user.has_group('mobile__shop.group_sales_manager'):
            raise UserError("Only Sales Managers can reject this form.")
        return {
        'type': 'ir.actions.act_window',
        'res_model': 'mobile.shop.reject.wizard',
        'view_mode': 'form',
        'view_id': self.env.ref('mobile__shop.mobile_shop_reject_wizard_form').id,
        'target': 'new',
        'context': {'default_reject_reason': self.reject_reason},
        }


    def action_cancel(self):
        self.state = 'cancel'

    def action_reset_to_draft(self):
        self.state = 'draft'

    def name_get(self):
        result = []
        for record in self:
            name = record.sequence_id if record.sequence_id != _('New') else 'New'
            result.append((record.id, name))
        return result

    def unlink(self):
        for record in self:
            if record.state != 'draft':
                raise UserError("You cannot delete confirmed records.")
        return super(MobileShop, self).unlink()


class MobileShopServiceLine(models.Model):
    _name = 'mobile.shop.service.line'
    _description = 'Mobile Shop Service Line'

    product_id = fields.Many2one('product.product', string='Product', required=True)
    qty = fields.Integer(string='Quantity', required=True, default=1)
    unit_price = fields.Float(related='product_id.list_price', string='Unit Price', store=True, readonly=False)
    subtotal = fields.Float(string='Subtotal', compute='_compute_subtotal', store=True)

    mobile_shop_id = fields.Many2one('mobile.shop', string='Mobile Shop', required=True)

    @api.depends('qty', 'unit_price')
    def _compute_subtotal(self):
        for line in self:
            line.subtotal = line.qty * line.unit_price

class SaleOrderInherit(models.Model):

    _inherit = 'sale.order'

    vat = fields.Char(string="VAT", readonly=True)


    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        print("-----------------------onchange")
        if self.partner_id:
            self.vat = self.partner_id.vat


    def action_confirm(self):
        for order in self:
            if order.amount_total > 10000:
                raise UserError(_("You cannot confirm the Sale Order as the total amount exceeds 10,000."))
        return super(SaleOrderInherit, self).action_confirm()

    @api.constrains('validity_date')
    def _check_validity_date(self):
        """Validate that expiration date is not in the past for quotations"""
        for order in self:
            if order.state == 'draft' and order.validity_date and order.validity_date < date.today():
                raise ValidationError(_("The expiration date cannot be in the past for a Quotation Date."))
    


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    internal_reference = fields.Char(string="Internal Reference", store=True)
    category_name = fields.Many2one('product.category', string="Category Name", store=True)


    @api.onchange('product_id')
    def _onchange_product_id(self):
        print("-----------------------onchange")
        if self.product_id:
            self.internal_reference = self.product_id.default_code
            self.category_name = self.product_id.categ_id
        else:
            self.internal_reference = False
            self.category_name = False
     
    def _prepare_invoice_line(self, **optional_values):
        res = super(SaleOrderLine, self)._prepare_invoice_line(**optional_values)
        res.update({
            'internal_reference': self.internal_reference,
            'category_name': self.category_name.id,
        })
        return res

class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    internal_reference = fields.Char(string="Internal Reference", readonly=True, store=True)
    category_name = fields.Many2one('product.category', string="Category Name", readonly=True, store=True)




