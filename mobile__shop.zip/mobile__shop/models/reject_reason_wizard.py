from odoo import models, fields, api

class RejectReasonWizard(models.TransientModel):
    _name = 'mobile.shop.reject.wizard'
    _description = 'Mobile Shop Reject RejectReasonWizard'

    reason = fields.Text(string='Rejection Reason', required=True)

    def action_reject(self):
        active_id = self.env.context.get('active_id')
        mobile_shop = self.env['mobile.shop'].browse(active_id)
        mobile_shop.state = 'rejected'
        mobile_shop.reject_reason = self.reason
